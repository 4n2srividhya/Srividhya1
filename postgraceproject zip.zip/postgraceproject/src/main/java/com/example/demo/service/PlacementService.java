package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Placement;

public interface PlacementService {

	Placement savePlacement(Placement placement);

	List<Placement> fetchPlacementList();

	Placement fetchPlacementById(long id);

	void deletePlacementById(long id);

	Placement updatePlacement(long placementId, Placement placement);

}
