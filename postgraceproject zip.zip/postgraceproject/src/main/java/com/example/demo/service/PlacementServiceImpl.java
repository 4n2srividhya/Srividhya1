package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Placement;
import com.example.demo.repository.PlacementRepository;
@Service
public class PlacementServiceImpl implements PlacementService{

	@Autowired
	PlacementRepository repository;
	
	@Override
	public Placement savePlacement(Placement placement) {
		// TODO Auto-generated method stub
		return repository.save(placement);
	}

	@Override
	public List<Placement> fetchPlacementList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Placement fetchPlacementById(long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public void deletePlacementById(long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}
	@Override
	public Placement updatePlacement(long placementId, Placement placement) {
		// TODO Auto-generated method stub
Placement placement2= repository.findById(placementId).get();
		
		if(Objects.nonNull(placement.getYear()) &&
			       !"".equals(placement.getYear())) {
			           placement2.setYear(placement.getYear());
			       }

			      
			       if(Objects.nonNull(placement.getName()) &&
			               !"".equalsIgnoreCase(placement.getName())) {
			           placement2.setName(placement.getName());
			       }

			       return repository.save(placement2);
	}

}
