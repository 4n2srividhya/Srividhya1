package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Placement;
import com.example.demo.service.PlacementService;

@RestController
public class PlacementController {

	@Autowired
	PlacementService service;
	@PostMapping("/placements")
	public Placement savePlacement(@RequestBody Placement placement) {
		return service.savePlacement(placement);
	}
	
	@GetMapping("/placements")
	public List<Placement> fetchPlacementList() {
		return service.fetchPlacementList();
	}
	
	@GetMapping("/placements/{id}")
	public Placement fetchPlacementById(@PathVariable("id") long id) {
		return service.fetchPlacementById(id);
	}
	
	@DeleteMapping("/placements/{id}")
	public String deletePlacementById(@PathVariable("id") long id) {
		service.deletePlacementById(id);
		return "Placement deleted Successfully!!";
	}
	@PutMapping("/placements/{id}")
	public Placement updatePlacement(@PathVariable("id") long placementId,@RequestBody Placement placement) {
		return service.updatePlacement(placementId,placement);
	}
}
